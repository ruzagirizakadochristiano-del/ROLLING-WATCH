export interface Product {
  id: string;
  name: string;
  brand: string;
  price: number;
  description: string;
  image: string;
  category: 'Classic' | 'Sport' | 'Luxury' | 'Vintage';
  features: string[];
}

export interface User {
  id: string;
  username: string;
  email: string;
  registeredAt?: string;
  phone?: string;
}

export interface Admin {
  email: string;
  token: string;
}

export interface SiteConfig {
  name: string;
  address: string;
  phone: string;
  email: string;
  terms: string;
  policy: string;
  warranty: string;
  customerService: string;
  primaryColor: string;
  backgroundColor: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Order {
  id: string;
  userId: string;
  customerName: string;
  items: CartItem[];
  total: number;
  status: 'Pending' | 'Shipped' | 'Delivered' | 'Cancelled';
  date: string;
}

export interface Message {
  id: string;
  name: string;
  email: string;
  content: string;
  date: string;
}
