import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Mail, Lock, ShieldCheck, ArrowRight } from 'lucide-react';
import { Admin } from '../types';

interface AdminLoginProps {
  setAdmin: (admin: Admin) => void;
}

export default function AdminLogin({ setAdmin }: AdminLoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Strict Admin Credentials
    if (email === 'ruzagirizakadochristiano@gmail.com' && password === 'didier@1234!') {
      const adminData: Admin = {
        email,
        token: Math.random().toString(36).substring(2) + Date.now().toString(36),
      };
      localStorage.setItem('watch_store_admin', JSON.stringify(adminData));
      setAdmin(adminData);
    } else {
      setError('Invalid admin credentials. Access denied.');
    }
  };

  return (
    <div className="min-h-screen bg-luxury-black flex items-center justify-center p-6 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 border border-gold rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 border border-gold rounded-full blur-3xl animate-pulse delay-1000" />
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md z-10"
      >
        <div className="glass-card p-12 rounded-3xl border-gold/20 relative">
          <div className="text-center mb-12">
            <div className="w-20 h-20 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-gold/30">
              <ShieldCheck size={40} className="text-gold" />
            </div>
            <span className="text-gold text-[10px] uppercase tracking-[0.4em] font-bold mb-3 block">System Override</span>
            <h1 className="text-3xl font-serif text-white">Central Admin</h1>
          </div>

          <form onSubmit={handleLogin} className="space-y-8">
            <div>
              <label className="block text-[10px] uppercase tracking-[0.2em] text-gold font-bold mb-3 ml-1">Secure Email</label>
              <div className="relative">
                <Mail className="absolute left-5 top-1/2 -translate-y-1/2 text-white/20" size={18} />
                <input 
                  type="email" 
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@aeterna.ch"
                  className="w-full bg-white/5 border border-white/10 rounded-sm py-5 pl-14 pr-6 outline-none focus:border-gold/40 transition-all text-sm font-light"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] uppercase tracking-[0.2em] text-gold font-bold mb-3 ml-1">Access Key</label>
              <div className="relative">
                <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-white/20" size={18} />
                <input 
                  type="password" 
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-white/5 border border-white/10 rounded-sm py-5 pl-14 pr-6 outline-none focus:border-gold/40 transition-all text-sm font-light"
                />
              </div>
            </div>

            {error && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] uppercase tracking-widest font-bold py-4 px-6 rounded-sm text-center"
              >
                {error}
              </motion.div>
            )}

            <button 
              type="submit"
              className="w-full bg-gold text-black font-bold uppercase tracking-[0.3em] py-6 rounded-sm flex items-center justify-center space-x-3 hover:bg-gold-muted transition-all text-xs"
            >
              <span>Initialize Access</span>
              <ArrowRight size={16} />
            </button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-[9px] text-white/30 uppercase tracking-widest">Authorized Personnel Only • IP Logged</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
