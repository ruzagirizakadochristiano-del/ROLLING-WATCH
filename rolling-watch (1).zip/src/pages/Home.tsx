import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { Product, SiteConfig } from '../types';
import { ArrowRight, Star, Clock, ShieldCheck } from 'lucide-react';

export default function Home({ addToCart, products, config }: { addToCart: (p: any) => void, products: Product[], config: SiteConfig }) {
  const featured = products.slice(0, 3);

  return (
    <div className="w-full relative">
      {/* Accent Lines */}
      <div className="accent-line-v left-0 top-1/2 -translate-y-1/2 h-64" style={{ backgroundColor: config.primaryColor }} />
      <div className="absolute top-0 right-1/4 w-px h-full bg-white/[0.03]" />

      {/* Hero Section - Split Layout */}
      <section className="relative min-h-[calc(100vh-80px)] grid grid-cols-12 overflow-hidden border-b border-white/5">
        {/* Left Content */}
        <div className="col-span-12 lg:col-span-5 flex flex-col justify-center px-8 md:px-16 py-20 z-20">
          <motion.span 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            className="text-xs uppercase tracking-[0.4em] mb-6 font-semibold"
            style={{ color: config.primaryColor }}
          >
            Est. 1894 • Genève
          </motion.span>
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-6xl md:text-8xl font-serif leading-[0.9] mb-10 text-white"
          >
            The Zenith <br/><span className="italic" style={{ color: config.primaryColor }}>Chronograph</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-white/60 text-sm md:text-base leading-relaxed max-w-sm mb-12 font-light"
          >
            A masterpiece of precision engineering and timeless aesthetic. Hand-assembled by master horologists over 400 hours of meticulous craftsmanship.
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="flex flex-wrap gap-6"
          >
            <Link to="/shop" className="border px-10 py-5 text-xs font-bold uppercase tracking-[0.2em] hover:bg-gold hover:text-black transition-all" style={{ borderColor: config.primaryColor, color: config.primaryColor }}>
              Discover the Piece
            </Link>
            <button className="flex items-center gap-4 text-xs uppercase tracking-[0.2em] font-bold group">
              <span className="w-12 h-[1px] bg-white/40 group-hover:bg-gold transition-colors"></span>
              <span className="group-hover:text-gold transition-colors">Technical Specs</span>
            </button>
          </motion.div>
        </div>

        {/* Right Visual Area */}
        <div className="col-span-12 lg:col-span-7 relative flex items-center justify-center p-8 lg:p-0">
          {/* Abstract background circles */}
          <div className="absolute w-[300px] h-[300px] md:w-[600px] md:h-[600px] border rounded-full animate-[pulse_8s_infinite]" style={{ borderColor: `${config.primaryColor}1a` }} />
          <div className="absolute w-[220px] h-[220px] md:w-[450px] md:h-[450px] border rounded-full animate-[pulse_5s_infinite]" style={{ borderColor: `${config.primaryColor}33` }} />
          
          {/* Dynamic Watch Visual */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.8, rotate: -15 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            transition={{ type: 'spring', duration: 1.5 }}
            className="relative z-10 w-64 md:w-80"
          >
            <div className="aspect-[3/5] bg-gradient-to-b from-[#1A1A1A] to-luxury-black rounded-[40px] border border-white/10 shadow-2xl flex flex-col items-center justify-between p-6">
              <div className="w-12 h-20 bg-[#2A2A2A] rounded-t-lg -mt-12 border-x border-t border-white/5 shadow-xl" />
              
              <div className="w-full aspect-square rounded-full border-[12px] border-[#222] bg-luxury-black shadow-inner flex items-center justify-center relative overflow-hidden group">
                 {/* Watch Face Details */}
                 <div className="absolute inset-4 rounded-full border border-gold/20" />
                 <div className="font-serif italic text-2xl z-10" style={{ color: config.primaryColor }}>A</div>
                 
                 {/* Indices */}
                 <div className="absolute top-8 w-[1px] h-4 bg-gold" />
                 <div className="absolute bottom-8 w-[1px] h-4 bg-gold" />
                 <div className="absolute left-8 h-[1px] w-4 bg-gold" />
                 <div className="absolute right-8 h-[1px] w-4 bg-gold" />
                 
                 {/* Hands */}
                 <motion.div 
                  animate={{ rotate: 360 }}
                  transition={{ duration: 60, repeat: Infinity, ease: 'linear' }}
                  className="absolute w-[1px] h-24 bg-white bottom-[50%] origin-bottom" 
                 />
                 <motion.div 
                  animate={{ rotate: 360 }}
                  transition={{ duration: 3600, repeat: Infinity, ease: 'linear' }}
                  className="absolute w-[2px] h-16 bg-gold bottom-[50%] origin-bottom" 
                 />
              </div>

              <div className="w-12 h-20 bg-[#2A2A2A] rounded-b-lg -mb-12 border-x border-b border-white/5 shadow-xl" />
            </div>
          </motion.div>
          
          {/* Floating Data Points */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
            className="absolute top-20 md:top-32 right-8 md:right-16 text-right"
          >
            <div className="font-serif text-3xl md:text-5xl mb-1" style={{ color: config.primaryColor }}>$24,500</div>
            <div className="text-[10px] text-white/40 uppercase tracking-[0.2em] font-bold">Retail Exclusive</div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.7 }}
            className="absolute bottom-20 md:bottom-32 right-8 md:right-16 text-right"
          >
            <div className="text-white font-medium text-sm md:text-base">Automatic Calibre 82</div>
            <div className="text-[10px] text-white/40 uppercase tracking-[0.2em] font-bold">72 Hour Power Reserve</div>
          </motion.div>
        </div>
      </section>

      {/* Featured Works Section (Bottom Bar style from design) */}
      <section className="w-full bg-[#111] border-b border-white/5 flex flex-col md:flex-row items-center px-6 md:px-12 py-10 gap-8">
        <div className="text-[10px] uppercase tracking-[0.3em] font-bold w-full md:w-32 mb-4 md:mb-0" style={{ color: config.primaryColor }}>Latest Pieces</div>
        
        <div className="flex-1 flex flex-wrap gap-4">
          {featured.map((product) => (
            <Link 
              key={product.id}
              to={`/product/${product.id}`}
              className="group flex items-center gap-4 bg-white/5 p-4 pr-10 rounded-sm border border-transparent hover:border-gold/30 transition-all"
            >
              <div className="w-14 h-14 bg-luxury-black rounded-full border border-white/10 overflow-hidden">
                <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-125 transition-transform" />
              </div>
              <div className="flex flex-col">
                <span className="text-[12px] font-bold uppercase tracking-wider text-white">{product.name}</span>
                <span className="text-[10px] text-white/40 uppercase tracking-widest">{product.category} Edition</span>
              </div>
            </Link>
          ))}
        </div>

        <div className="flex gap-4">
          <Link to="/shop" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-[18px] hover:border-gold hover:text-gold transition-all">&rarr;</Link>
        </div>
      </section>

      {/* Detailed Boutique Grid */}
      <section className="py-32 px-6 md:px-12 max-w-7xl mx-auto">
        <div className="text-center mb-24">
          <span className="text-xs uppercase tracking-[0.5em] mb-4 block" style={{ color: config.primaryColor }}>The Selection</span>
          <h2 className="text-4xl md:text-6xl font-serif">Horological Excellence</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {products.slice(0, 3).map((product, idx) => (
            <motion.div 
              key={product.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group relative"
            >
              <div className="aspect-[4/5] rounded-sm overflow-hidden bg-[#1A1A1A] mb-8 border border-white/5 group-hover:border-gold/30 transition-colors">
                <img src={product.image} alt={product.name} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-1000" />
                <div className="absolute inset-0 bg-gradient-to-t from-luxury-black via-transparent to-transparent opacity-60" />
                
                {/* Hover Action */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => addToCart(product)} className="w-16 h-16 rounded-full text-black flex items-center justify-center hover:scale-110 transition-transform" style={{ backgroundColor: config.primaryColor }}>
                    <ArrowRight size={24} />
                  </button>
                </div>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase tracking-[0.3em] text-white/40">{product.brand}</span>
                  <span className="font-medium" style={{ color: config.primaryColor }}>${product.price.toLocaleString()}</span>
                </div>
                <h4 className="text-2xl font-serif group-hover:text-gold transition-colors">
                  <Link to={`/product/${product.id}`}>{product.name}</Link>
                </h4>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Values Section */}
      <section className="py-32 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-1 lg:grid-cols-12 gap-20 items-center">
          <div className="lg:col-span-5">
            <h3 className="text-4xl md:text-5xl font-serif mb-8 leading-tight">Mastering <br/><span className="italic" style={{ color: config.primaryColor }}>Complexity</span></h3>
            <p className="text-white/50 font-light leading-relaxed mb-10">
              Beyond timekeeping, {config.name} represents the peak of human ingenuity. Each movement is a symphony of hundreds of microscopic parts working in perfect harmony.
            </p>
            <div className="space-y-8">
              {[
                { label: 'Precision Engineering', value: '400+ Components' },
                { label: 'Craftsmanship', value: 'Perpetual Excellence' },
                { label: 'Heritage', value: 'Geneva Hallmark' }
              ].map(stat => (
                <div key={stat.label} className="border-b border-white/5 pb-4">
                  <div className="text-[10px] uppercase tracking-[0.2em] mb-1 font-bold" style={{ color: config.primaryColor }}>{stat.label}</div>
                  <div className="text-xl font-serif">{stat.value}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="lg:col-span-7 aspect-[16/9] bg-[#1A1A1A] rounded-sm overflow-hidden border border-white/5 relative">
            <img src="https://images.unsplash.com/photo-1509048191080-d2984bad6ae5?q=80&w=1500&auto=format&fit=crop" className="w-full h-full object-cover opacity-40 grayscale hover:grayscale-0 transition-all duration-1000" />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-20 h-20 rounded-full border border-gold/40 flex items-center justify-center text-gold cursor-pointer hover:bg-gold hover:text-black transition-all">
                <Clock size={32} />
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* Contact Section */}
      <section className="py-32 border-t border-white/5 bg-luxury-gray/50">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <span className="text-xs uppercase tracking-[0.5em] mb-4 block" style={{ color: config.primaryColor }}>Inquiries</span>
          <h2 className="text-4xl md:text-5xl font-serif mb-12">Global Concierge</h2>
          <form className="space-y-6" onSubmit={(e) => {
            e.preventDefault();
            const form = e.target as HTMLFormElement;
            const msg = {
              id: Math.random().toString(36).substr(2, 9),
              name: (form.elements.namedItem('name') as HTMLInputElement).value,
              email: (form.elements.namedItem('email') as HTMLInputElement).value,
              content: (form.elements.namedItem('message') as HTMLTextAreaElement).value,
              date: new Date().toISOString().split('T')[0]
            };
            const existing = JSON.parse(localStorage.getItem('watch_store_messages') || '[]');
            localStorage.setItem('watch_store_messages', JSON.stringify([...existing, msg]));
            form.reset();
            alert('Your inquiry has been received by our concierge.');
          }}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <input name="name" required placeholder="Full Name" className="bg-white/5 border border-white/10 p-5 text-sm outline-none focus:border-gold/40 rounded-sm" />
              <input name="email" required type="email" placeholder="Email Address" className="bg-white/5 border border-white/10 p-5 text-sm outline-none focus:border-gold/40 rounded-sm" />
            </div>
            <textarea name="message" required rows={5} placeholder="Your Inquiry" className="w-full bg-white/5 border border-white/10 p-5 text-sm outline-none focus:border-gold/40 rounded-sm resize-none" />
            <button type="submit" className="w-full text-black font-bold uppercase tracking-[0.3em] py-6 rounded-sm hover:bg-gold-muted transition-all text-xs" style={{ backgroundColor: config.primaryColor }}>
              Direct Transmission
            </button>
          </form>
        </div>
      </section>
    </div>
  );
}
