import React, { useState, useEffect } from 'react';
import { Link, Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Watch, 
  Users, 
  ShoppingBag, 
  MessageSquare, 
  Settings, 
  LogOut, 
  Plus, 
  Edit2, 
  Trash2, 
  TrendingUp,
  DollarSign,
  Package,
  Eye,
  Search,
  ChevronRight,
  ArrowUpRight,
  ShieldCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Admin, Product, User, Order, Message, SiteConfig } from '../types';

interface AdminDashboardProps {
  admin: Admin;
  logout: () => void;
  products: Product[];
  setProducts: (products: Product[]) => void;
  config: SiteConfig;
  setConfig: (config: SiteConfig) => void;
}

export default function AdminDashboard({ admin, logout, products, setProducts, config, setConfig }: AdminDashboardProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const [customers, setCustomers] = useState<User[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);

  useEffect(() => {
    // Load data from localStorage
    const savedUsers = localStorage.getItem('watch_store_users');
    if (savedUsers) setCustomers(JSON.parse(savedUsers));

    const savedOrders = localStorage.getItem('watch_store_orders');
    if (savedOrders) {
      setOrders(JSON.parse(savedOrders));
    } else {
      // Mock initial orders
      const mockOrders: Order[] = [
        { id: '#ORD-1002', userId: '1', customerName: 'John Doe', total: 36500, status: 'Delivered', date: '2026-04-20', items: [] },
        { id: '#ORD-1003', userId: '2', customerName: 'Jane Smith', total: 6400, status: 'Shipped', date: '2026-04-28', items: [] },
      ];
      localStorage.setItem('watch_store_orders', JSON.stringify(mockOrders));
      setOrders(mockOrders);
    }

    const savedMessages = localStorage.getItem('watch_store_messages');
    if (savedMessages) {
      setMessages(JSON.parse(savedMessages));
    } else {
      // Mock initial messages
      const mockMsgs: Message[] = [
        { id: '1', name: 'Marco Rossi', email: 'marco@example.com', content: 'Interested in bespoke engravings for the Day-Date...', date: '2026-04-25' }
      ];
      localStorage.setItem('watch_store_messages', JSON.stringify(mockMsgs));
      setMessages(mockMsgs);
    }
  }, []);

  const navItems = [
    { label: 'Performance', path: '', icon: LayoutDashboard },
    { label: 'Products', path: 'products', icon: Watch },
    { label: 'Customers', path: 'customers', icon: Users },
    { label: 'Orders', path: 'orders', icon: ShoppingBag },
    { label: 'Messages', path: 'messages', icon: MessageSquare },
    { label: 'Settings', path: 'settings', icon: Settings },
  ];

  const isActive = (path: string) => {
    const current = location.pathname.replace('/admin/dashboard', '');
    if (path === '' && current === '') return true;
    if (path !== '' && current.startsWith('/' + path)) return true;
    return false;
  };

  return (
    <div className="min-h-screen bg-luxury-black flex">
      {/* Sidebar */}
      <aside className="w-72 bg-luxury-gray border-r border-white/5 flex flex-col h-screen sticky top-0">
        <div className="p-10 border-b border-white/5">
          <div className="flex flex-col">
            <span className="text-xl font-serif font-bold tracking-[0.2em] text-gold uppercase">ROLLING WATCH</span>
            <span className="text-[9px] tracking-[0.4em] text-white/30 uppercase mt-1">Management Console</span>
          </div>
        </div>

        <nav className="flex-grow p-6 space-y-2 mt-8">
          {navItems.map(item => (
            <Link 
              key={item.label}
              to={item.path === '' ? '/admin/dashboard' : `/admin/dashboard/${item.path}`}
              className={`w-full flex items-center space-x-4 p-4 rounded-sm text-xs uppercase tracking-widest font-bold transition-all ${
                isActive(item.path) 
                ? 'bg-gold text-black' 
                : 'text-white/50 hover:bg-white/5 hover:text-white'
              }`}
            >
              <item.icon size={18} />
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>

        <div className="p-6 border-t border-white/5">
          <button 
            onClick={logout}
            className="w-full flex items-center space-x-4 p-4 rounded-sm text-xs uppercase tracking-widest font-bold text-red-400 hover:bg-red-400/10 transition-all"
          >
            <LogOut size={18} />
            <span>Terminate Session</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow flex flex-col h-screen overflow-y-auto bg-luxury-black p-8 lg:p-16">
        <header className="flex justify-between items-center mb-16">
          <h2 className="text-4xl font-serif">
            {navItems.find(i => isActive(i.path))?.label || 'Dashboard'}
          </h2>
          <div className="flex items-center space-x-6">
            <div className="text-right">
              <p className="text-xs text-white uppercase tracking-widest font-bold">{admin.email.split('@')[0]}</p>
              <p className="text-[9px] text-white/40 uppercase tracking-widest">Root Administrator</p>
            </div>
            <div className="w-12 h-12 rounded-full border border-gold/40 p-1">
              <div className="w-full h-full bg-gold rounded-full flex items-center justify-center text-black font-bold">A</div>
            </div>
          </div>
        </header>

        <Routes>
          <Route path="/" element={<AdminPerformance orders={orders} customers={customers} products={products} />} />
          <Route path="/products" element={<AdminProducts products={products} setProducts={setProducts} />} />
          <Route path="/customers" element={<AdminCustomers customers={customers} />} />
          <Route path="/orders" element={<AdminOrders orders={orders} setOrders={setOrders} />} />
          <Route path="/messages" element={<AdminMessages messages={messages} setMessages={setMessages} />} />
          <Route path="/settings" element={<AdminSettings admin={admin} config={config} setConfig={setConfig} />} />
        </Routes>
      </main>
    </div>
  );
}

// --- SUB-COMPONENTS ---

function AdminPerformance({ orders, customers, products }: { orders: Order[], customers: User[], products: Product[] }) {
  const stats = [
    { label: 'Annual Revenue', value: `$${orders.reduce((a, b) => a + b.total, 0).toLocaleString()}`, icon: DollarSign, trend: '+12.5%' },
    { label: 'Registered Clients', value: customers.length, icon: Users, trend: '+4.2%' },
    { label: 'Active Collection', value: products.length, icon: Watch, trend: 'Stable' },
    { label: 'Orders Fulfilled', value: orders.length, icon: ShoppingBag, trend: '+8.1%' },
  ];

  return (
    <div className="space-y-12">
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
        {stats.map(stat => (
          <div key={stat.label} className="glass-card p-8 rounded-sm border-white/5 relative group">
            <div className="accent-line-h bottom-0 left-0" />
            <div className="flex items-center justify-between mb-8">
              <div className="p-3 bg-gold/10 text-gold rounded-sm group-hover:scale-110 transition-transform">
                <stat.icon size={24} />
              </div>
              <span className={`text-[10px] font-bold ${stat.trend.startsWith('+') ? 'text-green-400' : 'text-white/40'}`}>
                {stat.trend}
              </span>
            </div>
            <p className="text-[10px] uppercase tracking-[0.2em] text-white/40 font-bold mb-2">{stat.label}</p>
            <p className="text-3xl font-serif">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 glass-card p-10 rounded-sm border-white/5">
          <div className="flex items-center justify-between mb-10">
            <h4 className="text-xl font-serif">Revenue Trajectory</h4>
            <select className="bg-white/5 border border-white/10 text-[10px] uppercase tracking-widest font-bold p-2 outline-none">
              <option>Last 30 Days</option>
              <option>Last Quarter</option>
            </select>
          </div>
          <div className="h-64 flex items-end justify-between space-x-2">
            {[40, 65, 45, 80, 55, 90, 70, 85, 100].map((h, i) => (
              <div key={i} className="flex-grow flex flex-col items-center group">
                <div 
                  style={{ height: `${h}%` }} 
                  className="w-full bg-gold/20 group-hover:bg-gold/40 transition-all relative"
                >
                  <div className="absolute top-0 left-0 w-full h-[1px] bg-gold" />
                </div>
                <span className="text-[8px] uppercase tracking-tighter text-white/30 mt-4">W0{i+1}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-card p-10 rounded-sm border-white/5">
          <h4 className="text-xl font-serif mb-10">Sales by Category</h4>
          <div className="space-y-8">
            {[
              { label: 'Luxury', percent: 65, total: '$145k' },
              { label: 'Sport', percent: 25, total: '$56k' },
              { label: 'Classic', percent: 10, total: '$22k' }
            ].map(cat => (
              <div key={cat.label} className="space-y-3">
                <div className="flex justify-between text-[10px] uppercase tracking-widest font-bold">
                  <span>{cat.label}</span>
                  <span className="text-gold">{cat.total}</span>
                </div>
                <div className="w-full h-1 bg-white/5 overflow-hidden">
                  <div style={{ width: `${cat.percent}%` }} className="h-full bg-gold" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function AdminProducts({ products, setProducts }: { products: Product[], setProducts: (p: Product[]) => void }) {
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<Product>>({
    name: '', brand: '', price: 0, category: 'Luxury', description: '', image: '', features: []
  });

  const handleDelete = (id: string) => {
    const updated = products.filter(p => p.id !== id);
    setProducts(updated);
    localStorage.setItem('watch_store_products', JSON.stringify(updated));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let updated;
    if (editingId) {
      updated = products.map(p => p.id === editingId ? { ...p, ...formData } : p);
    } else {
      const newProduct: Product = {
        ...formData as Product,
        id: Math.random().toString(36).substr(2, 9),
        features: formData.features || []
      };
      updated = [...products, newProduct];
    }
    setProducts(updated as Product[]);
    localStorage.setItem('watch_store_products', JSON.stringify(updated));
    setIsAdding(false);
    setEditingId(null);
    setFormData({ name: '', brand: '', price: 0, category: 'Luxury', description: '', image: '', features: [] });
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20" size={16} />
            <input 
              type="text" 
              placeholder="Filter Collection..." 
              className="bg-white/5 border border-white/10 rounded-sm py-3 pl-12 pr-6 outline-none text-xs tracking-widest focus:border-gold/40 w-80"
            />
          </div>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-gold text-black px-8 py-3 rounded-sm text-[10px] uppercase tracking-[0.2em] font-bold flex items-center space-x-2 hover:bg-gold-muted transition-all"
        >
          <Plus size={16} />
          <span>New Acquisition</span>
        </button>
      </div>

      <div className="glass-card rounded-sm overflow-hidden border-white/5">
        <table className="w-full text-left">
          <thead className="bg-white/5">
            <tr className="text-[10px] uppercase tracking-[0.3em] font-bold text-white/40">
              <th className="px-8 py-6">Reference</th>
              <th className="px-8 py-6">Model</th>
              <th className="px-8 py-6">Category</th>
              <th className="px-8 py-6">Valuation</th>
              <th className="px-8 py-6 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="text-xs tracking-widest">
            {products.map(product => (
              <tr key={product.id} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
                <td className="px-8 py-6 text-gold font-bold">#{product.id.toUpperCase()}</td>
                <td className="px-8 py-6">
                  <div className="flex items-center space-x-4">
                    <img src={product.image} className="w-10 h-10 object-cover rounded-sm border border-white/10" />
                    <div>
                      <p className="font-bold">{product.name}</p>
                      <p className="text-[10px] text-white/30">{product.brand}</p>
                    </div>
                  </div>
                </td>
                <td className="px-8 py-6 text-white/60">{product.category}</td>
                <td className="px-8 py-6 font-bold">${product.price.toLocaleString()}</td>
                <td className="px-8 py-6">
                  <div className="flex justify-end space-x-4">
                    <button 
                      onClick={() => { setEditingId(product.id); setFormData(product); setIsAdding(true); }}
                      className="p-2 text-white/40 hover:text-gold transition-colors"
                    >
                      <Edit2 size={16} />
                    </button>
                    <button 
                      onClick={() => handleDelete(product.id)}
                      className="p-2 text-white/40 hover:text-red-400 transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal for Add/Edit */}
      <AnimatePresence>
        {isAdding && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => { setIsAdding(false); setEditingId(null); }}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-2xl bg-luxury-gray border border-white/10 p-12 rounded-sm relative z-[110]"
            >
              <h3 className="text-2xl font-serif mb-10">{editingId ? 'Edit Timepiece' : 'Register New Timepiece'}</h3>
              <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div>
                    <label className="block text-[9px] uppercase tracking-widest text-gold font-bold mb-2">Model Name</label>
                    <input 
                      required
                      className="w-full bg-white/5 border border-white/10 p-4 text-xs outline-none focus:border-gold/40"
                      value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] uppercase tracking-widest text-gold font-bold mb-2">Brand</label>
                    <input 
                      required
                      className="w-full bg-white/5 border border-white/10 p-4 text-xs outline-none focus:border-gold/40"
                      value={formData.brand} onChange={e => setFormData({ ...formData, brand: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] uppercase tracking-widest text-gold font-bold mb-2">Price ($)</label>
                    <input 
                      required type="number"
                      className="w-full bg-white/5 border border-white/10 p-4 text-xs outline-none focus:border-gold/40"
                      value={formData.price} onChange={e => setFormData({ ...formData, price: Number(e.target.value) })}
                    />
                  </div>
                </div>
                <div className="space-y-6">
                  <div>
                    <label className="block text-[9px] uppercase tracking-widest text-gold font-bold mb-2">Image URL</label>
                    <input 
                      required
                      className="w-full bg-white/5 border border-white/10 p-4 text-xs outline-none focus:border-gold/40"
                      value={formData.image} onChange={e => setFormData({ ...formData, image: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] uppercase tracking-widest text-gold font-bold mb-2">Category</label>
                    <select 
                      className="w-full bg-white/5 border border-white/10 p-4 text-xs outline-none focus:border-gold/40"
                      value={formData.category} onChange={e => setFormData({ ...formData, category: e.target.value as any })}
                    >
                      <option>Luxury</option>
                      <option>Sport</option>
                      <option>Classic</option>
                      <option>Vintage</option>
                    </select>
                  </div>
                  <div className="flex gap-4 pt-4">
                    <button type="submit" className="flex-grow bg-gold text-black font-bold uppercase tracking-widest py-4 text-[10px]">
                      Confirm Record
                    </button>
                    <button type="button" onClick={() => setIsAdding(false)} className="flex-grow border border-white/10 font-bold uppercase tracking-widest py-4 text-[10px]">
                      Cancel
                    </button>
                  </div>
                </div>
                <div className="col-span-2">
                  <label className="block text-[9px] uppercase tracking-widest text-gold font-bold mb-2">Provenance & Stats</label>
                  <textarea 
                    rows={4}
                    className="w-full bg-white/5 border border-white/10 p-4 text-xs outline-none focus:border-gold/40 resize-none"
                    value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })}
                  />
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function AdminCustomers({ customers }: { customers: User[] }) {
  return (
    <div className="glass-card rounded-sm overflow-hidden border-white/5">
      <table className="w-full text-left">
        <thead className="bg-white/5">
          <tr className="text-[10px] uppercase tracking-[0.3em] font-bold text-white/40">
            <th className="px-8 py-6">ID</th>
            <th className="px-8 py-6">Client</th>
            <th className="px-8 py-6">Email Address</th>
            <th className="px-8 py-6">Registration Date</th>
            <th className="px-8 py-6 text-right">Loyalty Status</th>
          </tr>
        </thead>
        <tbody className="text-xs tracking-widest">
          {customers.length === 0 ? (
            <tr><td colSpan={5} className="p-20 text-center text-white/20">No registered collectors found.</td></tr>
          ) : (
            customers.map(c => (
              <tr key={c.id} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
                <td className="px-8 py-6 font-mono text-white/40">{c.id}</td>
                <td className="px-8 py-6 font-bold">{c.username}</td>
                <td className="px-8 py-6 text-white/60">{c.email}</td>
                <td className="px-8 py-6 text-white/30">2026-05-01</td>
                <td className="px-8 py-6 text-right">
                  <span className="text-[9px] uppercase font-bold tracking-widest text-gold bg-gold/10 px-3 py-1 rounded-full">Premier</span>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

function AdminOrders({ orders, setOrders }: { orders: Order[], setOrders: (o: Order[]) => void }) {
  const updateStatus = (id: string, newStatus: Order['status']) => {
    const updated = orders.map(o => o.id === id ? { ...o, status: newStatus } : o);
    setOrders(updated);
    localStorage.setItem('watch_store_orders', JSON.stringify(updated));
  };

  return (
    <div className="glass-card rounded-sm overflow-hidden border-white/5">
      <table className="w-full text-left">
        <thead className="bg-white/5">
          <tr className="text-[10px] uppercase tracking-[0.3em] font-bold text-white/40">
            <th className="px-8 py-6">Reference</th>
            <th className="px-8 py-6">Customer</th>
            <th className="px-8 py-6">Date</th>
            <th className="px-8 py-6">Total</th>
            <th className="px-8 py-6 text-right">Workflow Status</th>
          </tr>
        </thead>
        <tbody className="text-xs tracking-widest">
          {orders.map(order => (
            <tr key={order.id} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
              <td className="px-8 py-6 font-bold text-gold">{order.id}</td>
              <td className="px-8 py-6">{order.customerName}</td>
              <td className="px-8 py-6 text-white/40">{order.date}</td>
              <td className="px-8 py-6 font-bold font-sans">${order.total.toLocaleString()}</td>
              <td className="px-8 py-6 text-right">
                <select 
                  className={`bg-luxury-black border text-[9px] uppercase tracking-widest font-bold px-3 py-1 rounded-full outline-none ${
                    order.status === 'Delivered' ? 'border-green-500/30 text-green-500' : 
                    order.status === 'Shipped' ? 'border-blue-500/30 text-blue-500' : 'border-gold/30 text-gold'
                  }`}
                  value={order.status}
                  onChange={(e) => updateStatus(order.id, e.target.value as any)}
                >
                  <option>Pending</option>
                  <option>Shipped</option>
                  <option>Delivered</option>
                  <option>Cancelled</option>
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function AdminMessages({ messages, setMessages }: { messages: Message[], setMessages: (m: Message[]) => void }) {
  const handleDelete = (id: string) => {
    const updated = messages.filter(m => m.id !== id);
    setMessages(updated);
    localStorage.setItem('watch_store_messages', JSON.stringify(updated));
  };

  return (
    <div className="space-y-8">
      {messages.length === 0 ? (
        <div className="glass-card flex flex-col items-center justify-center p-32 space-y-4">
          <MessageSquare size={48} className="text-white/10" />
          <p className="text-white/30 text-sm tracking-widest uppercase">Inbox Isolated • No Messages</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {messages.map(msg => (
            <div key={msg.id} className="glass-card p-10 rounded-sm border-white/5 relative group">
              <div className="flex justify-between items-start mb-8">
                <div>
                  <h4 className="text-lg font-serif font-bold text-white mb-1">{msg.name}</h4>
                  <p className="text-[10px] text-gold uppercase tracking-[0.2em] font-bold">{msg.email}</p>
                </div>
                <button 
                  onClick={() => handleDelete(msg.id)}
                  className="p-2 text-white/20 hover:text-red-400 transition-colors"
                >
                  <Trash2 size={18} />
                </button>
              </div>
              <p className="text-sm font-light text-white/60 leading-relaxed mb-8 italic italic">"{msg.content}"</p>
              <div className="flex justify-between items-center text-[9px] uppercase tracking-widest text-white/30 font-bold border-t border-white/5 pt-6">
                <span>Received: {msg.date}</span>
                <span className="flex items-center space-x-2 text-gold group-hover:underline cursor-pointer">
                  <span>Draft Response</span>
                  <ArrowUpRight size={12} />
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function AdminSettings({ admin, config, setConfig }: { admin: Admin, config: SiteConfig, setConfig: (c: SiteConfig) => void }) {
  const [localConfig, setLocalConfig] = useState<SiteConfig>(config);

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    setConfig(localConfig);
    alert('Site configuration updated successfully.');
  };

  return (
    <div className="space-y-12 pb-20">
      <form onSubmit={handleUpdate} className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Brand & Identity */}
        <div className="glass-card p-10 rounded-sm border-white/5 space-y-8">
          <h4 className="text-xl font-serif mb-8 border-b border-white/5 pb-6">Brand Identity</h4>
          <div className="space-y-6">
            <div>
              <label className="block text-[9px] uppercase tracking-widest text-gold font-bold mb-3">Website Name</label>
              <input 
                className="w-full bg-white/5 border border-white/10 p-5 text-xs outline-none focus:border-gold/40" 
                value={localConfig.name}
                onChange={e => setLocalConfig({...localConfig, name: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-[9px] uppercase tracking-widest text-gold font-bold mb-3">Headquarters Address</label>
              <input 
                className="w-full bg-white/5 border border-white/10 p-5 text-xs outline-none focus:border-gold/40" 
                value={localConfig.address}
                onChange={e => setLocalConfig({...localConfig, address: e.target.value})}
              />
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-[9px] uppercase tracking-widest text-gold font-bold mb-3">Secure Phone</label>
                <input 
                  className="w-full bg-white/5 border border-white/10 p-5 text-xs outline-none focus:border-gold/40" 
                  value={localConfig.phone}
                  onChange={e => setLocalConfig({...localConfig, phone: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[9px] uppercase tracking-widest text-gold font-bold mb-3">Concierge Email</label>
                <input 
                  className="w-full bg-white/5 border border-white/10 p-5 text-xs outline-none focus:border-gold/40" 
                  value={localConfig.email}
                  onChange={e => setLocalConfig({...localConfig, email: e.target.value})}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Visual Theme */}
        <div className="glass-card p-10 rounded-sm border-white/5 space-y-8">
          <h4 className="text-xl font-serif mb-8 border-b border-white/5 pb-6">Environmental Theme</h4>
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-[9px] uppercase tracking-widest text-gold font-bold mb-3">Primary Accent (Hex)</label>
                <div className="flex items-center space-x-4">
                  <input 
                    type="color"
                    className="w-12 h-12 bg-transparent border-none outline-none cursor-pointer"
                    value={localConfig.primaryColor}
                    onChange={e => setLocalConfig({...localConfig, primaryColor: e.target.value})}
                  />
                  <input 
                    className="flex-grow bg-white/5 border border-white/10 p-5 text-xs outline-none focus:border-gold/40" 
                    value={localConfig.primaryColor}
                    onChange={e => setLocalConfig({...localConfig, primaryColor: e.target.value})}
                  />
                </div>
              </div>
              <div>
                <label className="block text-[9px] uppercase tracking-widest text-gold font-bold mb-3">Background Core (Hex)</label>
                <div className="flex items-center space-x-4">
                  <input 
                    type="color"
                    className="w-12 h-12 bg-transparent border-none outline-none cursor-pointer"
                    value={localConfig.backgroundColor}
                    onChange={e => setLocalConfig({...localConfig, backgroundColor: e.target.value})}
                  />
                  <input 
                    className="flex-grow bg-white/5 border border-white/10 p-5 text-xs outline-none focus:border-gold/40" 
                    value={localConfig.backgroundColor}
                    onChange={e => setLocalConfig({...localConfig, backgroundColor: e.target.value})}
                  />
                </div>
              </div>
            </div>
            <p className="text-[10px] text-white/30 italic">Note: Changes to colors will propagate instantly across the entire customer interface.</p>
          </div>
        </div>

        {/* Legal & Policy */}
        <div className="glass-card p-10 rounded-sm border-white/5 space-y-8 lg:col-span-2">
          <h4 className="text-xl font-serif mb-8 border-b border-white/5 pb-6">Legal & Policy Directives</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="space-y-6">
              <div>
                <label className="block text-[9px] uppercase tracking-widest text-gold font-bold mb-3">Terms & Conditions</label>
                <textarea 
                  rows={6}
                  className="w-full bg-white/5 border border-white/10 p-5 text-xs outline-none focus:border-gold/40 resize-none" 
                  value={localConfig.terms}
                  onChange={e => setLocalConfig({...localConfig, terms: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[9px] uppercase tracking-widest text-gold font-bold mb-3">Privacy Directive</label>
                <textarea 
                  rows={6}
                  className="w-full bg-white/5 border border-white/10 p-5 text-xs outline-none focus:border-gold/40 resize-none" 
                  value={localConfig.policy}
                  onChange={e => setLocalConfig({...localConfig, policy: e.target.value})}
                />
              </div>
            </div>
            <div className="space-y-6">
              <div>
                <label className="block text-[9px] uppercase tracking-widest text-gold font-bold mb-3">Warranty Statement</label>
                <textarea 
                  rows={6}
                  className="w-full bg-white/5 border border-white/10 p-5 text-xs outline-none focus:border-gold/40 resize-none" 
                  value={localConfig.warranty}
                  onChange={e => setLocalConfig({...localConfig, warranty: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[9px] uppercase tracking-widest text-gold font-bold mb-3">Customer Service Charter</label>
                <textarea 
                  rows={6}
                  className="w-full bg-white/5 border border-white/10 p-5 text-xs outline-none focus:border-gold/40 resize-none" 
                  value={localConfig.customerService}
                  onChange={e => setLocalConfig({...localConfig, customerService: e.target.value})}
                />
              </div>
            </div>
          </div>
          <div className="pt-6 border-t border-white/5 flex justify-end">
            <button 
              type="submit"
              className="bg-gold text-black font-bold uppercase tracking-[0.3em] px-16 py-6 text-xs hover:bg-gold-muted transition-all"
            >
              Commit Global Manifest
            </button>
          </div>
        </div>

        {/* Security Info */}
        <div className="glass-card p-10 rounded-sm border-white/5 lg:col-span-2">
          <div className="flex items-center space-x-6">
            <div className="p-4 bg-white/5 rounded-full">
              <ShieldCheck className="text-gold" size={32} />
            </div>
            <div>
              <p className="text-sm font-serif">Logged in as {admin.email}</p>
              <p className="text-[10px] text-white/30 uppercase tracking-widest">Active Root Session Control</p>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
