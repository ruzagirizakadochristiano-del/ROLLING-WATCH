import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Mail, Lock, LogIn, ArrowRight } from 'lucide-react';
import { User } from '../types';

export default function Login({ setUser }: { setUser: (u: User) => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Check for Admin Credentials first
    if (email === 'ruzagirizakadochristiano@gmail.com' && password === 'didier@1234!') {
      const adminData = {
        email,
        token: Math.random().toString(36).substring(2) + Date.now().toString(36),
      };
      localStorage.setItem('watch_store_admin', JSON.stringify(adminData));
      // Note: We need a way to set the admin state. Since Login is designed for users, 
      // it might be better to just redirect to the admin login page or handle it in App.tsx
      // But based on user request, let's make it work here by refreshing or using a passed prop
      window.location.href = '/admin/dashboard';
      return;
    }

    // Standard User Validation
    const usersJson = localStorage.getItem('watch_store_users');
    const users = usersJson ? JSON.parse(usersJson) : [];
    
    const foundUser = users.find((u: any) => u.email === email && u.password === password);

    if (foundUser) {
      const userToStore = { id: foundUser.id, username: foundUser.username, email: foundUser.email };
      localStorage.setItem('watch_store_user', JSON.stringify(userToStore));
      setUser(userToStore);
      navigate('/dashboard');
    } else {
      setError('Invalid email or password. Please try again.');
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-20 px-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="glass-card p-10 rounded-3xl border-white/10 relative overflow-hidden">
          {/* Decorative background element */}
          <div className="absolute -top-20 -right-20 w-40 h-40 bg-gold/5 blur-3xl rounded-full" />
          
          <div className="text-center mb-10">
            <span className="text-gold text-[10px] uppercase tracking-[0.4em] mb-4 block font-bold">Member Access</span>
            <h1 className="text-4xl font-serif mb-3">Welcome Back</h1>
            <p className="text-white/40 text-sm font-light">Access your exclusive collection and private concierge.</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-8">
            <div>
              <label className="block text-[10px] uppercase tracking-[0.2em] text-gold font-bold mb-3 ml-1">Identity</label>
              <div className="relative">
                <Mail className="absolute left-5 top-1/2 -translate-y-1/2 text-white/20" size={18} />
                <input 
                  type="email" 
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email address"
                  className="w-full bg-white/5 border border-white/10 rounded-sm py-5 pl-14 pr-6 outline-none focus:border-gold/40 transition-all font-light text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] uppercase tracking-[0.2em] text-gold font-bold mb-3 ml-1">Security Key</label>
              <div className="relative">
                <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-white/20" size={18} />
                <input 
                  type="password" 
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  className="w-full bg-white/5 border border-white/10 rounded-sm py-5 pl-14 pr-6 outline-none focus:border-gold/40 transition-all font-light text-sm"
                />
              </div>
            </div>

            {error && (
              <motion.p 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="text-red-400 text-[11px] uppercase tracking-wider bg-red-400/5 py-4 px-6 rounded-sm border border-red-400/10 text-center"
              >
                {error}
              </motion.p>
            )}

            <button 
              type="submit"
              className="w-full bg-gold text-black font-bold uppercase tracking-[0.2em] py-6 rounded-sm flex items-center justify-center space-x-3 hover:bg-gold-muted transition-all text-xs"
            >
              <LogIn size={20} />
              <span>Authenticate</span>
            </button>
          </form>

          <div className="mt-10 text-center space-y-6">
            <Link to="/signup" className="group flex items-center justify-center space-x-2 text-sm text-gray-400 hover:text-white transition-colors">
              <span>Don't have an account? Create one</span>
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
