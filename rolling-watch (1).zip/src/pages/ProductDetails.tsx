import { useParams, Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Star, Shield, Clock, RotateCcw, Truck, ShoppingCart } from 'lucide-react';
import { Product, SiteConfig } from '../types';

export default function ProductDetails({ addToCart, products, config }: { addToCart: (p: any) => void, products: Product[], config: SiteConfig }) {
  const { id } = useParams();
  const product = products.find(p => p.id === id);

  if (!product) {
    return (
      <div className="py-40 text-center">
        <h2 className="text-3xl font-serif mb-4">Product Not Found</h2>
        <Link to="/shop" className="underline" style={{ color: config.primaryColor }}>Return to Shop</Link>
      </div>
    );
  }

  const related = products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 3);

  return (
    <div className="pb-24">
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-12">
        {/* Breadcrumbs */}
        <div className="flex items-center space-x-2 text-xs uppercase tracking-widest text-gray-500 mb-12">
          <Link to="/" className="hover:text-gold">Home</Link>
          <span>/</span>
          <Link to="/shop" className="hover:text-gold">Shop</Link>
          <span>/</span>
          <span className="text-gray-300">{product.name}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 xl:gap-24 mb-24">
          {/* Image Section */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative"
          >
            <div className="aspect-square rounded-3xl overflow-hidden glass-card border-white/5">
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="grid grid-cols-4 gap-4 mt-6">
              {[1,2,3,4].map(i => (
                <div key={i} className="aspect-square rounded-xl overflow-hidden glass-card border-white/5 hover:border-gold/50 cursor-pointer transition-all">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover opacity-60" />
                </div>
              ))}
            </div>
          </motion.div>

          {/* Info Section */}
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-col"
          >
            <span className="uppercase tracking-[0.4em] text-xs mb-4 font-bold" style={{ color: config.primaryColor }}>Ref. {product.brand} • {product.id}</span>
            <h1 className="text-5xl md:text-7xl font-serif mb-8 leading-tight">{product.name}</h1>
            
            <div className="flex items-center space-x-6 mb-10">
              <div className="flex" style={{ color: config.primaryColor }}>
                {[1,2,3,4,5].map(s => <Star key={s} size={14} fill="currentColor" />)}
              </div>
              <span className="text-white/40 text-xs uppercase tracking-widest font-medium">4.9 / 5.0 Rating</span>
              <span className="text-white/10">|</span>
              <span className="text-xs font-bold uppercase tracking-[0.2em]" style={{ color: config.primaryColor }}>Geneva Hallmark</span>
            </div>

            <p className="text-4xl font-serif text-white mb-10">${product.price.toLocaleString()}</p>
            
            <p className="text-white/60 font-light leading-relaxed mb-12 text-lg">
              {product.description}
            </p>

            <div className="space-y-6 mb-12">
              <h4 className="uppercase tracking-[0.3em] text-[10px] font-bold" style={{ color: config.primaryColor }}>Specifications</h4>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {product.features.map(f => (
                  <li key={f} className="flex items-center space-x-4 text-sm text-white/70">
                    <div className="w-1 h-1 rounded-full" style={{ backgroundColor: config.primaryColor }} />
                    <span className="font-light tracking-wide">{f}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="flex flex-col sm:flex-row gap-6 mb-16">
              <button 
                onClick={() => addToCart(product)}
                className="flex-grow text-black font-bold uppercase tracking-[0.2em] py-6 rounded-sm flex items-center justify-center space-x-4 hover:bg-gold-muted transition-all text-xs"
                style={{ backgroundColor: config.primaryColor }}
              >
                <ShoppingCart size={18} />
                <span>Reserve this Piece</span>
              </button>
              <button className="flex-grow sm:flex-grow-0 px-10 py-6 border border-white/20 text-white font-bold uppercase tracking-[0.2em] rounded-sm hover:bg-white/5 transition-all text-xs">
                Inquiry
              </button>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-2 gap-6 pt-10 border-t border-white/5">
              <div className="flex items-center space-x-4">
                <Truck size={24} style={{ color: config.primaryColor }} />
                <div className="text-xs uppercase tracking-widest font-bold">
                  <p>Express</p>
                  <p className="text-gray-500">Shipping</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <Shield size={24} style={{ color: config.primaryColor }} />
                <div className="text-xs uppercase tracking-widest font-bold">
                  <p>Extended</p>
                  <p className="text-gray-500">Warranty</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <RotateCcw size={24} style={{ color: config.primaryColor }} />
                <div className="text-xs uppercase tracking-widest font-bold">
                  <p>14-Day</p>
                  <p className="text-gray-500">Returns</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <Clock size={24} style={{ color: config.primaryColor }} />
                <div className="text-xs uppercase tracking-widest font-bold">
                  <p>Swiss</p>
                  <p className="text-gray-500">Precision</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Related Products */}
        {related.length > 0 && (
          <div>
            <h3 className="text-3xl font-serif mb-12">Related Pieces</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
              {related.map(p => (
                <Link key={p.id} to={`/product/${p.id}`} className="group glass-card p-6 rounded-2xl border-white/5 transition-all">
                  <div className="aspect-square rounded-xl overflow-hidden mb-6 bg-white/5">
                    <img src={p.image} alt={p.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                  </div>
                  <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: config.primaryColor }}>{p.brand}</p>
                  <h4 className="font-serif text-lg mb-4 group-hover:text-gold transition-colors">{p.name}</h4>
                  <p className="font-bold">${p.price.toLocaleString()}</p>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
