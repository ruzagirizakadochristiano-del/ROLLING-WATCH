import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Mail, Lock, User as UserIcon, UserPlus, ArrowRight } from 'lucide-react';
import { User } from '../types';

export default function Signup({ setUser }: { setUser: (u: User) => void }) {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    // Mock Registration
    const usersJson = localStorage.getItem('watch_store_users');
    const users = usersJson ? JSON.parse(usersJson) : [];
    
    if (users.find((u: any) => u.email === email)) {
      setError('An account with this email already exists.');
      return;
    }

    const newUser = { 
      id: Math.random().toString(36).substr(2, 9),
      username,
      email,
      password 
    };

    users.push(newUser);
    localStorage.setItem('watch_store_users', JSON.stringify(users));

    const userProfile = { id: newUser.id, username: newUser.username, email: newUser.email };
    localStorage.setItem('watch_store_user', JSON.stringify(userProfile));
    
    setUser(userProfile);
    navigate('/dashboard');
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-20 px-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="glass-card p-10 rounded-3xl border-white/10 relative overflow-hidden">
          <div className="absolute -top-20 -left-20 w-40 h-40 bg-gold/5 blur-3xl rounded-full" />
          
          <div className="text-center mb-10">
            <h1 className="text-4xl font-serif mb-3">Begin Heritage</h1>
            <p className="text-gray-400 font-light">Join the circle of Lumina members.</p>
          </div>

          <form onSubmit={handleSignup} className="space-y-6">
            <div>
              <label className="block text-xs uppercase tracking-widest text-gold font-bold mb-2 ml-1">Username</label>
              <div className="relative">
                <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                <input 
                  type="text" 
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="HorologyFan"
                  className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 outline-none focus:border-gold/50 transition-all font-light"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs uppercase tracking-widest text-gold font-bold mb-2 ml-1">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                <input 
                  type="email" 
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="collector@luxury.ch"
                  className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 outline-none focus:border-gold/50 transition-all font-light"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs uppercase tracking-widest text-gold font-bold mb-2 ml-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                <input 
                  type="password" 
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 outline-none focus:border-gold/50 transition-all font-light"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs uppercase tracking-widest text-gold font-bold mb-2 ml-1">Confirm Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                <input 
                  type="password" 
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 outline-none focus:border-gold/50 transition-all font-light"
                />
              </div>
            </div>

            {error && (
              <motion.p 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="text-red-400 text-sm bg-red-400/10 py-3 px-4 rounded-xl border border-red-400/20"
              >
                {error}
              </motion.p>
            )}

            <button 
              type="submit"
              className="w-full gold-gradient text-black font-bold uppercase tracking-widest py-5 rounded-2xl flex items-center justify-center space-x-3 hover:scale-[1.02] transition-all"
            >
              <UserPlus size={20} />
              <span>Create Account</span>
            </button>
          </form>

          <div className="mt-10 text-center">
            <Link to="/login" className="group flex items-center justify-center space-x-2 text-sm text-gray-400 hover:text-white transition-colors">
              <span>Already a member? Sign in</span>
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
