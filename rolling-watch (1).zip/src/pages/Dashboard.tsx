import { motion } from 'motion/react';
import { User as UserIcon, Package, Settings, LogOut, Shield, ChevronRight } from 'lucide-react';
import { User } from '../types';

export default function Dashboard({ user, logout }: { user: User, logout: () => void }) {
  return (
    <div className="py-20 px-4 md:px-8 max-w-7xl mx-auto">
      <div className="flex flex-col lg:flex-row gap-12">
        {/* Sidebar Nav */}
        <aside className="w-full lg:w-80 space-y-4">
          <div className="glass-card p-8 rounded-3xl border-white/5 text-center mb-10">
            <div className="w-24 h-24 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-gold/20">
              <UserIcon size={40} className="text-gold" />
            </div>
            <h2 className="text-2xl font-serif mb-1">{user.username}</h2>
            <p className="text-gold uppercase tracking-widest text-[10px] font-bold">VIP Collector</p>
          </div>

          <div className="space-y-2">
            {[
              { icon: Package, label: 'Order History', active: true },
              { icon: Shield, label: 'My Warranty' },
              { icon: Settings, label: 'Account Settings' },
            ].map(item => (
              <button 
                key={item.label}
                className={`w-full flex items-center justify-between p-5 rounded-2xl border transition-all ${
                  item.active 
                  ? 'bg-gold/10 border-gold/30 text-gold' 
                  : 'bg-white/5 border-white/5 hover:border-white/20'
                }`}
              >
                <div className="flex items-center space-x-4">
                  <item.icon size={20} />
                  <span className="font-medium tracking-wide">{item.label}</span>
                </div>
                <ChevronRight size={16} className="opacity-40" />
              </button>
            ))}
            <button 
              onClick={logout}
              className="w-full flex items-center space-x-4 p-5 rounded-2xl bg-red-400/5 border border-red-400/10 text-red-400 hover:bg-red-400/10 transition-all text-left"
            >
              <LogOut size={20} />
              <span className="font-medium tracking-wide">Logout</span>
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <div className="flex-grow space-y-10">
          <section>
            <h3 className="text-3xl font-serif mb-8">Order History</h3>
            <div className="glass-card rounded-3xl border-white/5 p-8">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="text-xs uppercase tracking-widest text-gray-500 border-b border-white/5 pb-4">
                      <th className="pb-4 font-bold">Order ID</th>
                      <th className="pb-4 font-bold">Date</th>
                      <th className="pb-4 font-bold">Status</th>
                      <th className="pb-4 font-bold text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody className="text-sm font-light">
                    <tr className="border-b border-white/5">
                      <td className="py-6 font-mono">#LM-98241</td>
                      <td className="py-6 whitespace-nowrap">Oct 12, 2025</td>
                      <td className="py-6">
                        <span className="px-3 py-1 bg-green-500/10 text-green-500 rounded-full text-[10px] uppercase tracking-widest font-bold">Delivered</span>
                      </td>
                      <td className="py-6 text-right font-bold">$36,500.00</td>
                    </tr>
                    <tr className="border-b border-white/5 opacity-60">
                      <td className="py-6 font-mono">#LM-81024</td>
                      <td className="py-6 whitespace-nowrap">Jul 22, 2024</td>
                      <td className="py-6">
                        <span className="px-3 py-1 bg-gray-500/10 text-gray-500 rounded-full text-[10px] uppercase tracking-widest font-bold">Completed</span>
                      </td>
                      <td className="py-6 text-right font-bold">$7,200.00</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="glass-card p-8 rounded-3xl border-white/5">
              <h4 className="text-xl font-serif mb-4">Concierge Support</h4>
              <p className="text-gray-400 font-light mb-6">Access your dedicated personal watch concierge for expert advice and private viewings.</p>
              <button className="text-gold uppercase tracking-widest text-xs font-bold border-b border-gold pb-1 hover:opacity-70 transition-opacity">Contact Consultant</button>
            </div>
            <div className="glass-card p-8 rounded-3xl border-white/5">
              <h4 className="text-xl font-serif mb-4">Exclusive Events</h4>
              <p className="text-gray-400 font-light mb-6">You have 2 invitations to upcoming private luxury horology events in Zurich and Paris.</p>
              <button className="text-gold uppercase tracking-widest text-xs font-bold border-b border-gold pb-1 hover:opacity-70 transition-opacity">View Invitations</button>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
