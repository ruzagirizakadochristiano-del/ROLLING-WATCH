import { motion } from 'motion/react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Filter, SlidersHorizontal, ShoppingBag } from 'lucide-react';
import { Product, SiteConfig } from '../types';

export default function Shop({ addToCart, products, config }: { addToCart: (p: any) => void, products: Product[], config: SiteConfig }) {
  const [filter, setFilter] = useState('All');
  const [priceRange, setPriceRange] = useState(150000);

  const filteredProducts = products.filter(p => {
    const categoryMatch = filter === 'All' || p.category === filter;
    const priceMatch = p.price <= priceRange;
    return categoryMatch && priceMatch;
  });

  const categories = ['All', 'Luxury', 'Sport', 'Classic', 'Vintage'];

  return (
    <div className="py-20 px-4 md:px-8 max-w-7xl mx-auto">
      <div className="mb-16">
        <span className="text-xs uppercase tracking-[0.5em] mb-4 block" style={{ color: config.primaryColor }}>Selection</span>
        <h1 className="text-5xl md:text-7xl font-serif mb-6">The Boutique</h1>
        <p className="text-white/50 font-light max-w-2xl leading-relaxed">Browse our exquisite selection of fine watches. Use the filters to find the perfect timepiece for your collection.</p>
      </div>

      <div className="flex flex-col lg:flex-row gap-16">
        {/* Sidebar Filters */}
        <aside className="w-full lg:w-72 space-y-12">
          <div>
            <div className="flex items-center space-x-3 uppercase tracking-[0.3em] text-[10px] font-bold mb-8" style={{ color: config.primaryColor }}>
              <Filter size={14} />
              <span>Category</span>
            </div>
            <div className="flex flex-wrap lg:flex-col gap-4">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setFilter(cat)}
                  className={`text-left text-xs uppercase tracking-widest py-3 px-6 rounded-sm border transition-all ${
                    filter === cat 
                    ? 'text-black font-bold' 
                    : 'bg-white/5 border-white/5 hover:border-gold/40'
                  }`}
                  style={filter === cat ? { backgroundColor: config.primaryColor, borderColor: config.primaryColor } : {}}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between uppercase tracking-widest text-xs font-bold mb-6" style={{ color: config.primaryColor }}>
              <div className="flex items-center space-x-2">
                <SlidersHorizontal size={14} />
                <span>Price (Max)</span>
              </div>
              <span className="text-white">${priceRange.toLocaleString()}</span>
            </div>
            <input 
              type="range" 
              min="5000" 
              max="150000" 
              step="5000"
              value={priceRange}
              onChange={(e) => setPriceRange(Number(e.target.value))}
              className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-gold"
            />
            <div className="flex justify-between text-[10px] text-gray-500 mt-2">
              <span>$5k</span>
              <span>$150k</span>
            </div>
          </div>
        </aside>

        {/* Product Grid */}
        <div className="flex-grow">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
            {filteredProducts.map((product, idx) => (
              <motion.div
                key={product.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, delay: idx * 0.05 }}
                className="group glass-card rounded-2xl overflow-hidden hover:border-gold/40 transition-all border-white/5"
              >
                <Link to={`/product/${product.id}`} className="block relative aspect-square overflow-hidden bg-white/5">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <span className="text-white text-xs uppercase tracking-widest font-bold bg-luxury-black/60 px-6 py-2 rounded-full border border-white/20">View Details</span>
                  </div>
                </Link>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="text-[10px] uppercase tracking-widest mb-1" style={{ color: config.primaryColor }}>{product.brand}</p>
                      <h3 className="font-serif text-lg leading-tight">{product.name}</h3>
                    </div>
                    <span className="text-xs bg-white/10 px-2 py-0.5 rounded text-gray-300">{product.category}</span>
                  </div>
                  <div className="flex items-center justify-between mt-6">
                    <span className="text-xl font-bold">${product.price.toLocaleString()}</span>
                    <button 
                      onClick={() => addToCart(product)}
                      className="p-3 text-black rounded-full transition-all"
                      style={{ backgroundColor: config.primaryColor }}
                    >
                      <ShoppingBag size={18} />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="py-20 text-center">
              <p className="text-gray-500 mb-4">No watches found matching your criteria.</p>
              <button 
                onClick={() => { setFilter('All'); setPriceRange(150000); }}
                className="text-gold underline"
              >
                Reset Filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
