import { Product } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Day-Date 40',
    brand: 'Rolex',
    price: 36500,
    category: 'Luxury',
    description: 'The Rolex Day-Date 40 is a prestigious timepiece featuring the iconic day and date display, crafted in 18 ct yellow gold.',
    image: 'https://images.unsplash.com/photo-1547996160-81dfa63595aa?q=80&w=1000&auto=format&fit=crop',
    features: ['18 ct Yellow Gold', 'President Bracelet', 'Mechanical Movement']
  },
  {
    id: '2',
    name: 'Speedmaster Moonwatch',
    brand: 'Omega',
    price: 6400,
    category: 'Sport',
    description: 'The Omega Speedmaster Moonwatch Professional is one of the world’s most iconic timepieces, having been part of six lunar missions.',
    image: 'https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?q=80&w=1000&auto=format&fit=crop',
    features: ['Manual-winding', 'Tachymeter', 'Stainless Steel']
  },
  {
    id: '3',
    name: 'Nautilus 5711',
    brand: 'Patek Philippe',
    price: 125000,
    category: 'Luxury',
    description: 'The Nautilus 5711 self-winding wristwatch in steel, with its horizontally embossed dial and integrated bracelet, is the quintessential luxury sports watch.',
    image: 'https://images.unsplash.com/photo-1523170335258-f5ed11844a49?q=80&w=1000&auto=format&fit=crop',
    features: ['Steel Case', 'Blue Gradated Dial', 'Self-winding Mechanical']
  },
  {
    id: '4',
    name: 'Royal Oak Selfwinding',
    brand: 'Audemars Piguet',
    price: 45000,
    category: 'Luxury',
    description: 'The Royal Oak Selfwinding in stainless steel with a "Grande Tapisserie" dial is timeless elegance in a sporty package.',
    image: 'https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?q=80&w=1000&auto=format&fit=crop',
    features: ['Grand Tapisserie Dial', 'Octagonal Bezel', 'Steel Bracelet']
  },
  {
    id: '5',
    name: 'Submariner Date',
    brand: 'Rolex',
    price: 10500,
    category: 'Sport',
    description: 'The benchmark among divers’ watches, the Submariner Date exemplifies the historic link between Rolex and the underwater world.',
    image: 'https://images.unsplash.com/photo-1587836374828-4dbaba94ee0e?q=80&w=1000&auto=format&fit=crop',
    features: ['Cerachrom Bezel', 'Unidirectional Rotatable Bezel', 'Oystersteel']
  },
  {
    id: '6',
    name: 'Santos de Cartier',
    brand: 'Cartier',
    price: 7200,
    category: 'Classic',
    description: 'The Santos watch was created by Louis Cartier in 1904 for his friend, the aviator Alberto Santos-Dumont.',
    image: 'https://images.unsplash.com/photo-1619134778706-7015533a6150?q=80&w=1000&auto=format&fit=crop',
    features: ['Interchangeable Straps', 'Roman Numerals', 'Square Case']
  }
];
