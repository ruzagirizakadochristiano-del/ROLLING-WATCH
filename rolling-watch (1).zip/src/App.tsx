import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Shop from './pages/Shop';
import ProductDetails from './pages/ProductDetails';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import AdminLogin from './pages/AdminLogin';
import AdminDashboard from './pages/AdminDashboard';
import { useState, useEffect } from 'react';
import { User, CartItem, Product, Admin, SiteConfig } from './types';
import { products as initialProducts } from './data/products';

const DEFAULT_CONFIG: SiteConfig = {
  name: 'ROLLING WATCH',
  address: 'Rue du Rhône 1, 1204 Genève, Switzerland',
  phone: '+41 22 123 45 67',
  email: 'concierge@rollingwatch.ch',
  terms: 'Terms of service details go here...',
  policy: 'Privacy policy details go here...',
  warranty: 'Lifetime mechanical warranty on all certified timepieces.',
  customerService: '24/7 Global concierge service available for registered members.',
  primaryColor: '#C5A059',
  backgroundColor: '#0A0A0A'
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [admin, setAdmin] = useState<Admin | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [config, setConfig] = useState<SiteConfig>(DEFAULT_CONFIG);

  useEffect(() => {
    // Load Site Config
    const savedConfig = localStorage.getItem('watch_store_config');
    if (savedConfig) {
      setConfig(JSON.parse(savedConfig));
    } else {
      localStorage.setItem('watch_store_config', JSON.stringify(DEFAULT_CONFIG));
    }

    // Initialize Products in localStorage if not present
    const savedProducts = localStorage.getItem('watch_store_products');
    if (!savedProducts) {
      localStorage.setItem('watch_store_products', JSON.stringify(initialProducts));
      setProducts(initialProducts);
    } else {
      setProducts(JSON.parse(savedProducts));
    }

    // Check for logged in user
    const savedUser = localStorage.getItem('watch_store_user');
    if (savedUser) setUser(JSON.parse(savedUser));

    // Check for logged in admin
    const savedAdmin = localStorage.getItem('watch_store_admin');
    if (savedAdmin) setAdmin(JSON.parse(savedAdmin));

    // Load cart
    const savedCart = localStorage.getItem('watch_store_cart');
    if (savedCart) setCart(JSON.parse(savedCart));
  }, []);

  const logout = () => {
    localStorage.removeItem('watch_store_user');
    setUser(null);
  };

  const adminLogout = () => {
    localStorage.removeItem('watch_store_admin');
    setAdmin(null);
  };

  const addToCart = (product: any) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      const newCart = existing 
        ? prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)
        : [...prev, { ...product, quantity: 1 }];
      localStorage.setItem('watch_store_cart', JSON.stringify(newCart));
      return newCart;
    });
  };

  const removeFromCart = (id: string) => {
    setCart(prev => {
      const newCart = prev.filter(item => item.id !== id);
      localStorage.setItem('watch_store_cart', JSON.stringify(newCart));
      return newCart;
    });
  };

  const updateGlobalProducts = (newProducts: Product[]) => {
    setProducts(newProducts);
  };

  const updateGlobalConfig = (newConfig: SiteConfig) => {
    setConfig(newConfig);
    localStorage.setItem('watch_store_config', JSON.stringify(newConfig));
  };

  return (
    <BrowserRouter>
      <div 
        className="min-h-screen flex flex-col transition-colors duration-500"
        style={{ backgroundColor: config.backgroundColor, color: 'white' }}
      >
        {!admin && <Navbar config={config} user={user} logout={logout} cartCount={cart.reduce((a, b) => a + b.quantity, 0)} cartItems={cart} removeFromCart={removeFromCart} />}
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home config={config} addToCart={addToCart} products={products} />} />
            <Route path="/shop" element={<Shop config={config} addToCart={addToCart} products={products} />} />
            <Route path="/product/:id" element={<ProductDetails config={config} addToCart={addToCart} products={products} />} />
            <Route path="/login" element={user ? <Navigate to="/dashboard" /> : <Login setUser={setUser} />} />
            <Route path="/signup" element={user ? <Navigate to="/dashboard" /> : <Signup setUser={setUser} />} />
            <Route path="/dashboard" element={user ? <Dashboard user={user} logout={logout} /> : <Navigate to="/login" />} />
            
            {/* Admin Routes */}
            <Route path="/admin/login" element={admin ? <Navigate to="/admin/dashboard" /> : <AdminLogin setAdmin={setAdmin} />} />
            <Route 
              path="/admin/dashboard/*" 
              element={admin ? <AdminDashboard config={config} setConfig={updateGlobalConfig} admin={admin} logout={adminLogout} products={products} setProducts={updateGlobalProducts} /> : <Navigate to="/admin/login" />} 
            />
          </Routes>
        </main>
        {!admin && <Footer config={config} />}
      </div>
    </BrowserRouter>
  );
}
