import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, User as UserIcon, LogOut, Search, Menu, X, Trash2 } from 'lucide-react';
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { User, CartItem, SiteConfig } from '../types';

interface NavbarProps {
  config: SiteConfig;
  user: User | null;
  logout: () => void;
  cartCount: number;
  cartItems: CartItem[];
  removeFromCart: (id: string) => void;
}

export default function Navbar({ config, user, logout, cartCount, cartItems, removeFromCart }: NavbarProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const navigate = useNavigate();

  return (
    <nav className="sticky top-0 z-50 bg-luxury-black/80 backdrop-blur-md border-b px-6 md:px-12 py-5" style={{ borderColor: `${config.primaryColor}33` }}>
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Mobile Menu Toggle */}
        <button className="md:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>

        {/* Logo */}
        <Link to="/" className="flex flex-col items-start group">
          <span className="text-2xl font-serif font-bold tracking-[0.3em] uppercase" style={{ color: config.primaryColor }}>{config.name}</span>
          <span className="text-[9px] tracking-[0.4em] text-white/50 uppercase leading-none mt-1">Swiss Horology</span>
        </Link>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center space-x-10 text-[10px] uppercase tracking-[0.2em] font-medium text-white/70">
          <Link to="/shop" className="hover:text-gold transition-colors">Collections</Link>
          <Link to="/shop" className="hover:text-gold transition-colors opacity-50 cursor-not-allowed">Heritage</Link>
          <Link to="/shop" className="hover:text-gold transition-colors opacity-50 cursor-not-allowed">Bespoke</Link>
        </div>

        {/* Action Icons */}
        <div className="flex items-center space-x-6">
          <div className="hidden lg:flex items-center bg-white/5 border border-white/10 rounded-full px-4 py-1.5 focus-within:border-gold/50 transition-all">
            <Search size={16} className="text-gray-400" />
            <input 
              type="text" 
              placeholder="Search..." 
              className="bg-transparent border-none outline-none text-xs px-2 w-32 focus:w-48 transition-all"
            />
          </div>

          {user ? (
            <div className="flex items-center space-x-4">
              <Link to="/dashboard" className="flex items-center space-x-2 text-sm hover:text-gold transition-colors">
                <UserIcon size={20} />
                <span className="hidden sm:inline">{user.username}</span>
              </Link>
              <button onClick={logout} className="p-2 hover:text-gold transition-colors" title="Logout">
                <LogOut size={20} />
              </button>
            </div>
          ) : (
            <div className="hidden sm:flex items-center space-x-4">
              <Link to="/login" className="text-sm hover:text-gold">Login</Link>
              <Link to="/signup" className="text-sm border px-4 py-1.5 rounded-full hover:bg-gold hover:text-black transition-all" style={{ color: config.primaryColor, borderColor: config.primaryColor }}>Sign Up</Link>
            </div>
          )}

          {/* Cart Toggle */}
          <button 
            className="relative p-2 hover:text-gold transition-colors"
            onClick={() => setIsCartOpen(!isCartOpen)}
          >
            <ShoppingCart size={24} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 text-black text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center transition-all" style={{ backgroundColor: config.primaryColor }}>
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden overflow-hidden bg-luxury-gray border-b border-white/5"
          >
            <div className="flex flex-col space-y-4 p-6 text-center tracking-widest uppercase text-sm">
              <Link to="/" onClick={() => setIsMenuOpen(false)}>Home</Link>
              <Link to="/shop" onClick={() => setIsMenuOpen(false)}>Shop</Link>
              <Link to="/login" onClick={() => setIsMenuOpen(false)}>Login</Link>
              <Link to="/signup" onClick={() => setIsMenuOpen(false)}>Sign Up</Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Cart Sidebar */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-black/60 z-[60]"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 bottom-0 w-full max-w-md bg-luxury-gray z-[70] p-8 flex flex-col"
            >
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-2xl font-serif">Your Collection</h2>
                <button onClick={() => setIsCartOpen(false)} className="hover:text-gold"><X size={24} /></button>
              </div>

              <div className="flex-grow overflow-y-auto space-y-6">
                {cartItems.length === 0 ? (
                  <p className="text-center text-gray-500 py-20">Your cart is empty.</p>
                ) : (
                  cartItems.map(item => (
                    <div key={item.id} className="flex space-x-4 border-b border-white/5 pb-4">
                      <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded" />
                      <div className="flex-grow">
                        <h4 className="font-serif text-lg">{item.name}</h4>
                        <p className="text-gold text-sm font-medium transition-all">${item.price.toLocaleString()}</p>
                        <p className="text-xs text-gray-400 mt-1">Qty: {item.quantity}</p>
                      </div>
                      <button onClick={() => removeFromCart(item.id)} className="text-gray-500 hover:text-red-400 self-center">
                        <Trash2 size={18} />
                      </button>
                    </div>
                  ))
                )}
              </div>

              {cartItems.length > 0 && (
                <div className="mt-8 pt-8 border-t border-white/10">
                  <div className="flex justify-between mb-4">
                    <span className="uppercase tracking-widest text-sm text-gray-400">Total</span>
                    <span className="text-xl font-bold">${cartItems.reduce((a, b) => a + (b.price * b.quantity), 0).toLocaleString()}</span>
                  </div>
                  <button className="w-full bg-gold text-black font-bold uppercase py-4 rounded-full tracking-widest hover:bg-gold-muted transition-colors">
                    Checkout
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </nav>
  );
}
