import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter, Mail, Phone, MapPin } from 'lucide-react';
import { SiteConfig } from '../types';

export default function Footer({ config }: { config: SiteConfig }) {
  return (
    <footer className="bg-luxury-black border-t border-white/5 pt-24 pb-12 px-6 md:px-12">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-24">
        <div className="space-y-8">
          <Link to="/" className="flex flex-col group">
            <span className="text-2xl font-serif font-bold tracking-[0.3em] uppercase" style={{ color: config.primaryColor }}>{config.name}</span>
            <span className="text-[9px] tracking-[0.4em] text-white/40 uppercase leading-none mt-1">Swiss Horology</span>
          </Link>
          <p className="text-white/40 font-light leading-relaxed text-sm">
            Dedicated to the pursuit of horological perfection. Established Geneva 1894.
          </p>
          <div className="flex space-x-5">
            <a href="#" className="p-2.5 border border-white/10 rounded-full hover:border-gold transition-all">
              <Instagram size={18} />
            </a>
            <a href="#" className="p-2.5 border border-white/10 rounded-full hover:border-gold transition-all">
              <Twitter size={18} />
            </a>
            <a href="#" className="p-2.5 border border-white/10 rounded-full hover:border-gold transition-all">
              <Mail size={18} />
            </a>
          </div>
        </div>

        <div>
          <h4 className="text-lg font-serif mb-6">Quick Links</h4>
          <ul className="space-y-4 text-sm text-gray-400 font-light">
            <li><Link to="/" className="hover:text-gold transition-colors">Home</Link></li>
            <li><Link to="/shop" className="hover:text-gold transition-colors">Boutique</Link></li>
            <li><a href="#" className="hover:text-gold transition-colors opacity-50 cursor-not-allowed">Our Heritage</a></li>
            <li><a href="#" className="hover:text-gold transition-colors opacity-50 cursor-not-allowed">Bespoke Service</a></li>
            <li><a href="#" className="hover:text-gold transition-colors opacity-50 cursor-not-allowed">Store Locator</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-lg font-serif mb-6">Support</h4>
          <ul className="space-y-4 text-sm text-white/40 font-light">
            <li><button onClick={() => alert(config.customerService)} className="hover:text-gold transition-colors">Customer Service</button></li>
            <li><button onClick={() => alert(config.warranty)} className="hover:text-gold transition-colors">Warranty & Repairs</button></li>
            <li><Link to="/admin/login" className="hover:text-gold transition-colors opacity-30">Concierge Portal</Link></li>
            <li><button onClick={() => alert(config.policy)} className="hover:text-gold transition-colors text-left uppercase text-[10px]">Privacy Policy</button></li>
            <li><button onClick={() => alert(config.terms)} className="hover:text-gold transition-colors text-left uppercase text-[10px]">Terms of Use</button></li>
          </ul>
        </div>

        <div>
          <h4 className="text-lg font-serif mb-6">Contact Us</h4>
          <ul className="space-y-4 text-sm text-gray-400 font-light">
            <li className="flex items-start space-x-3">
              <MapPin size={18} className="mt-1 shrink-0" style={{ color: config.primaryColor }} />
              <span>{config.address}</span>
            </li>
            <li className="flex items-center space-x-3">
              <Phone size={18} className="shrink-0" style={{ color: config.primaryColor }} />
              <span>{config.phone}</span>
            </li>
            <li className="flex items-center space-x-3">
              <Mail size={18} className="shrink-0" style={{ color: config.primaryColor }} />
              <span>{config.email}</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500 uppercase tracking-[0.2em]">
        <p>© 2026 {config.name}. ALL RIGHTS RESERVED.</p>
        <div className="flex space-x-8 mt-4 md:mt-0">
          <span>Swiss Precision</span>
          <span>Since 1892</span>
        </div>
      </div>
    </footer>
  );
}
